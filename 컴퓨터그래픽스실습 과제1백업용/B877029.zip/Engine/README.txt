전부 작동하는데
도형 하나는 뒤집어서 그려졌습니당!!ㅠㅠ

작동안할시->
속성-> VC++ 디렉터리->포함 디렉터리에
C:\Program Files (x86)\Microsoft DirectX SDK (June 2010)\Include

라이브러리 디렉터리는
C:\Program Files (x86)\Microsoft DirectX SDK (June 2010)\Lib\x86
을 추가해 주시면 잘 돌아갑니당!!!!